module Book where

data Book = Book
  { title :: String
  , author :: String
  , genre :: String
  } deriving (Show, Eq)

data Category = Category
  { categoryName :: String
  , books :: [Book]
  , subcategories :: [Category]
  } deriving (Show, Eq)