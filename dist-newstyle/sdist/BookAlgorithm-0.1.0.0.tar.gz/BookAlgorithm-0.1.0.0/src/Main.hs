module Main where

import Book ( Book(Book), Category(Category), countBooks )
import User ()
import Recommendation ()

main :: IO ()
main = do
  let book1 = Book "Book 1" "Author A" "Fiction"
  let book2 = Book "Book 2" "Author B" "Fiction"
  let subcategory = Category "Subcategory" [book2] []
  let category = Category "Main Category" [book1] [subcategory]
  putStrLn $ "Total books: " ++ show (countBooks category)


-- main :: IO ()
-- main = do
--   let book1 = Book { bookId = 1, title = "Book A", author = "Author X", genre = "Fantasy" }
--       book2 = Book { bookId = 2, title = "Book B", author = "Author Y", genre = "Drama" }
      
--       user = User { userId = 1, history = [book1] }
--       similarityMatrix = generateSimilarityMatrix [book1, book2, book3]
--       recommendations = recommendBooks user similarityMatrix
--   print recommendations